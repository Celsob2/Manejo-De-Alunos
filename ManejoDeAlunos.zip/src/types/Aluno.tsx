export interface Aluno {
    id: number;
    nome: string;
    idade: number;
    mensalidadePaga: boolean;
  }